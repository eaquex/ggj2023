


const scriptsInEvents = {

	async Evmultiplayer_Event6(runtime, localVars)
	{
		console.log("joined room !!!");
	},

	async Evmultiplayer_Event9(runtime, localVars)
	{
		console.log("left room !!!");
	},

	async Evmultiplayer_Event11(runtime, localVars)
	{
		console.log("peer connected !!!");
	},

	async Evmultiplayer_Event13(runtime, localVars)
	{
		console.log("peer disconnected !!!");
	},

	async Evmultiplayer_Event15(runtime, localVars)
	{
		console.log("host disconnected !!!");
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

